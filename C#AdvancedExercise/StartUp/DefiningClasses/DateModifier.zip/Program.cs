﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string date1 = Console.ReadLine();
            string date2 = Console.ReadLine();

            DateModifier dateModifier = new DateModifier();

            Console.WriteLine(dateModifier.CalculateDifference(date1, date2));
            // int numberOfFamily = int.Parse(Console.ReadLine());

            // Family family = new Family();
            // int count = 0;
            // for (int i = 0; i < numberOfFamily; i++)
            // {
            //     string[] personsArr = Console.ReadLine().Split();
            //     Person member = new Person(personsArr[0], int.Parse(personsArr[1]));
            //     family.AddMember(member);
            //     count++;
            // }

            // List<Person> ageMoreThan30 = family.PrintPersonsAgeMoreThan30();
            //var ageMoreThan30Years = ageMoreThan30.OrderBy(n => n.Name);

            // foreach (var item in ageMoreThan30Years)
            // {
            //     Console.WriteLine($"{item.Name} - {item.Age}");
            // }
            //Person oldestPerson = family.GetOldestMember();
            //Console.WriteLine(oldestPerson.Name + " " + oldestPerson.Age);

        }
    }
}
