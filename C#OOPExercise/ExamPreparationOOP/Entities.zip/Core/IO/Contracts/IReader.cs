﻿namespace WarCroft.Core.IO.Contracts
{
	public interface IReader
	{
		string ReadLine();
	}
}
