﻿namespace PlayersAndMonsters
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Elf elf = new Elf("MIsho", 14);
            System.Console.WriteLine(elf);
        }
    }
}