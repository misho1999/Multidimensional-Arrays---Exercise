﻿namespace MilitaryElite.Models
{
    internal interface IEgineer
    {
    }
}